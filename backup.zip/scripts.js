// Mobile Menu Toggle
const menuBtn = document.getElementById('menu-btn');
const mobileMenu = document.getElementById('mobile-menu');

menuBtn.addEventListener('click', () => {
    mobileMenu.classList.toggle('hidden');
});

// Smooth Scrolling for Navigation
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function(e) {
        e.preventDefault();
        
        const targetId = this.getAttribute('href');
        const targetElement = document.querySelector(targetId);
        
        window.scrollTo({
            top: targetElement.offsetTop - 80,
            behavior: 'smooth'
        });
        
        // Close mobile menu if open
        mobileMenu.classList.add('hidden');
    });
});

// Back to Top Button
const backToTopBtn = document.getElementById('back-to-top');

window.addEventListener('scroll', () => {
    if (window.pageYOffset > 300) {
        backToTopBtn.classList.remove('opacity-0', 'invisible');
        backToTopBtn.classList.add('opacity-100', 'visible');
    } else {
        backToTopBtn.classList.remove('opacity-100', 'visible');
        backToTopBtn.classList.add('opacity-0', 'invisible');
    }
});

backToTopBtn.addEventListener('click', () => {
    window.scrollTo({
        top: 0,
        behavior: 'smooth'
    });
});

// Gallery Filter
const filterBtns = document.querySelectorAll('.filter-btn');
const galleryContainer = document.querySelector('.gallery-container');

// Gallery Data
const galleryItems = [
    {
        id: 1,
        category: 'realism',
        img: 'https://images.unsplash.com/photo-1613082293061-3c03a2c6d1b7?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=687&q=80',
        title: 'Retrato Realista',
        artist: 'Ana Silva'
    },
    {
        id: 2,
        category: 'tribal',
        img: 'https://images.unsplash.com/photo-1620217491080-9ee1438f04ff?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=687&q=80',
        title: 'Tribal Maori',
        artist: 'Carlos Mendes'
    },
    {
        id: 3,
        category: 'dotwork',
        img: 'https://images.unsplash.com/photo-1605649487212-47bdab064df7?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1470&q=80',
        title: 'Flor Pontilhista',
        artist: 'Lúcia Oliveira'
    },
    {
        id: 4,
        category: 'realism',
        img: 'https://images.unsplash.com/photo-1612296727716-df02b8050d8e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1470&q=80',
        title: 'Animal Realista',
        artist: 'Ana Silva'
    },
    {
        id: 5,
        category: 'tribal',
        img: 'https://images.unsplash.com/photo-1612296278235-4c9a9a0d0f4c?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=687&q=80',
        title: 'Tribal Moderno',
        artist: 'Carlos Mendes'
    },
    {
        id: 6,
        category: 'dotwork',
        img: 'https://images.unsplash.com/photo-1612296278235-4c9a9a0d0f4c?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=687&q=80',
        title: 'Mandala Pontilhada',
        artist: 'Lúcia Oliveira'
    }
];

// Display gallery items
function displayGalleryItems(items) {
    galleryContainer.innerHTML = '';
    
    items.forEach(item => {
        const galleryItem = document.createElement('div');
        galleryItem.className = 'gallery-item bg-gray-800 rounded-xl overflow-hidden shadow-lg';
        galleryItem.setAttribute('data-category', item.category);
        
        galleryItem.innerHTML = `
            <div class="relative">
                <img src="${item.img}" alt="${item.title}" class="w-full h-64 object-cover">
                <div class="absolute inset-0 bg-gradient-to-t from-black to-transparent opacity-0 hover:opacity-100 transition-opacity duration-300 flex items-end p-4">
                    <div>
                        <h3 class="text-white font-bold">${item.title}</h3>
                        <p class="text-yellow-400 text-sm">por ${item.artist}</p>
                    </div>
                </div>
            </div>
        `;
        
        galleryContainer.appendChild(galleryItem);
    });
}

// Filter gallery items
filterBtns.forEach(btn => {
    btn.addEventListener('click', () => {
        // Update active button
        filterBtns.forEach(b => b.classList.remove('active', 'bg-yellow-500', 'text-black'));
        btn.classList.add('active', 'bg-yellow-500', 'text-black');
        
        const filter = btn.getAttribute('data-filter');
        
        if (filter === 'all') {
            displayGalleryItems(galleryItems);
        } else {
            const filteredItems = galleryItems.filter(item => item.category === filter);
            displayGalleryItems(filteredItems);
        }
    });
});

// Initialize gallery with all items
displayGalleryItems(galleryItems);

// FAQ Accordion
const faqBtns = document.querySelectorAll('.faq-btn');

faqBtns.forEach(btn => {
    btn.addEventListener('click', () => {
        const content = btn.nextElementSibling;
        const icon = btn.querySelector('i');
        
        content.classList.toggle('hidden');
        icon.classList.toggle('rotate-180');
    });
});

// Booking Form Submission
const bookingForm = document.querySelector('.booking-form');
const successModal = document.getElementById('success-modal');
const closeModal = document.getElementById('close-modal');
const modalOk = document.getElementById('modal-ok');

bookingForm.addEventListener('submit', (e) => {
    e.preventDefault();
    
    // In a real app, you would send the form data to a server here
    // For this example, we'll just show the success modal
    
    // Reset form
    bookingForm.reset();
    
    // Show success modal
    successModal.classList.remove('hidden');
});

// Close modal handlers
closeModal.addEventListener('click', () => {
    successModal.classList.add('hidden');
});

modalOk.addEventListener('click', () => {
    successModal.classList.add('hidden');
});

// Close modal when clicking outside
window.addEventListener('click', (e) => {
    if (e.target === successModal) {
        successModal.classList.add('hidden');
    }
});

